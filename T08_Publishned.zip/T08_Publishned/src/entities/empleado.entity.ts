import { Column, Entity, PrimaryColumn } from "typeorm";

@Entity({name: 'EMPLEADO'})
export class EmpleadoEntity {

  @PrimaryColumn({name: 'IDEMP', nullable: false})
  id: number;

  @Column({name: 'NOMEMP', nullable: false})
  nombre: string;

  @Column({name: 'APEEMP', nullable: false})
  apellido: string;

  @Column({name: 'TELEFEMP', nullable: false})
  telefono: string;

  @Column({name: 'EMAILEMP', nullable: false})
  email: string;

  @Column({name: 'DNIEMP', nullable: false})
  dni: string;

  @Column({name: 'ESTAEMP', nullable: false})
  estado: string;
}
