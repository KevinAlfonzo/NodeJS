import { Module } from "@nestjs/common";
import { AppController } from "./app.controller";
import { AppService } from "./app.service";
import { TypeOrmModule} from '@nestjs/typeorm';
import { EmpleadoController } from "./controllers/empleado.controller";
import { EmpleadoService } from "./services/empleado.service";
import { EmpleadoEntity } from "./entities/empleado.entity";

@Module({
  imports: [
    
    TypeOrmModule.forRoot({
      "type": "oracle",
      "host": "localhost",
      "port": 1521,
      "username": "ADMIN22",
      "password": "abc123",
      "sid": "xe",
      "entities": [__dirname + "/**/**.entity{.ts,.js}"],
      "synchronize": false,
      "logging": true
    }),
    TypeOrmModule.forFeature([EmpleadoEntity])
  ],
  controllers: [AppController, EmpleadoController],
  providers: [AppService, EmpleadoService]
})
export class AppModule {
}
